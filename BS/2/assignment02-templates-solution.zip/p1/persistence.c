#include "persistence.h"

void make_persistent(struct tm **time)
{
    (void) time;
}

void free_persistent(struct tm **time)
{
    (void) time;
}