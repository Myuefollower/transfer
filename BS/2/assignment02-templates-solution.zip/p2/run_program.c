#include "run_program.h"

#define ERROR_CODE 127

int run_program(char *file_path, char *arguments[])
{
    (void) file_path;
    (void) arguments;

    // remember to return ERROR_CODE on error.
    return ERROR_CODE;
}
