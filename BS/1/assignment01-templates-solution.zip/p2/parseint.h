#ifndef PARSEINT_H
#define PARSEINT_H

int parseDecimalChar(char c);

int parseInt(char *string);

#endif