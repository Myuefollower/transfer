#ifndef PRINT_H
#define PRINT_H
#include <inttypes.h>

void print_line(int64_t number, char *string);

#endif

